Readme Introduction

This is a guide for how to set up your readme for you IronHack Application

1. Krisp Markets

2. Keywords: freshness, price, crispness

3. Description of the datasets and function design
 * name: Farmers Market Directory and Geographic Data
 * link: https://catalog.data.gov/dataset/farmers-markets-geographic-data    
 * data type: text(string) and numbers(integers)
 * data columns used: market name, website, street, city, county, state, zip, vegetables
 * data amount: 8 columns
 Please provide a name+link+basicInfo to each dataset you have used.
 * name: Food Environment Atlas
 * link: https://catalog.data.gov/dataset/farmers-markets-geographic-data    
 * data type: text(string) and numbers(integers)
 * data columns used: state, county, LACCESS, PCT_LACCESS_POP10, GROC12
 * data amount: 5 columns, one row
 * [Y/N] Do you use the primary dataset �online climate data� from data.gov? Yes
 * [Y/N] [List] Are all these datasets from data.gov? If not, where are they coming from (links)? All from data.gov

4. Brief Description

 * This website will use datasets to provide accurate information on the best local vegetables. Data will be show the location of markets as well as the supply of food. I will focus on the availability, freshness and price of vegetables. 

 Fill in the structued description:
 * Map View:
	1. [Y/N] Basic Map with specific location (your map is located in a meaningful place, city of west lafayette for example). Will have
	2. [Y/N] Markers for location of markets. Will have 
	3. [Y/N] Labels for markets' names. Will have 
	4. [Y/N] InfoWindow to show detail information of a market. Will have 
	5. [Y/N] [describe] Any other cover on the map (for example, cloud cover to show the weather effect). Will have 

 * Data Visualization:
	1. [Y/N] [describe] Use Graph? What is the type? (bar chart, pie chart, radar chart ...) Could use a graph to show which markets have vegetables. No type yet.
	2. [Y/N] [List] Any interaction available on the graph? List them (enable click on numbers, drag on lines, change time/variables ...) Yes possibly
	
 * Interaction Form:
	1. [Y/N] [List] Any information output? list them. (text field, text area, label, plain HTML ...) Possibly show what markets are closest
	2. [Y/N] [List] Any operation option (filters)? List them. (search markets, search vegetables, filter based on price, sort based on convenience ...) Search on closeness
	3. [Y/N] [List] Any information input? List them. (comments, markers, user preference ...) Location
	4. [Y/N] [List] Interaction with Map? List them. (filter on price will affect map markers, sort on price will affect map markers, ...) No
	5. [Y/N] [List] Interaction with data visualization? List them. (filter, sort, set variables ...) No

5. Build Case
How can we build and access your project on a Linux/Unix machine if you use external dependencies besides HTML/CSS/Javascript?
List the dependencies you used, such as python, node.js, etc.
List the steps we should follow to build the project.
Your project will be built on Amazon Web Service, EC2, ubuntu 14.01 instance. Have Windows, not Linux

6. Test Case
Which browsers did you test your project on? Chrome, IE, Edge, Safari, or Firefox? Chrome

7. Additional information You Want to Share with Us
E.g. any problems you faced/fixed, where you reached out to for help, etc. Unaware of how to submit or how to directly answer questions


